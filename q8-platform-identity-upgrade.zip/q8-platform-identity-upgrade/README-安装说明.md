# qqqqqqq8 跨平台身份与头像补丁

这是一个**补丁包**，不是 q8 整个项目的源码压缩包。它包含新增文件、需要替换/修改的完整文件，以及一个自动应用补丁并运行项目类型检查的 GitHub Actions 工作流。

## 本补丁包含的改动

- 新增独立的平台身份存储：角色在不同平台可以分别保存网名、头像和自主修改冷却时间，不会反向修改 Character 本体资料。
- 新增独立社交头像库：自带 12 个非角色本人头像素材；不再把 Photo Library 中的角色照片作为新自主头像候选。外部素材可通过 `addSocialAvatarAsset()` 添加，外链须为 HTTPS 直链图片。
- 对现有 Chat、Weverse、Lysn、X/Twitter 主账号资料、小红书显示名解析，以及朋友圈通知中的作者昵称接入身份读取逻辑。
- Chat 的私聊备注要求同时输出 `[备注依据:...]`。缺少依据标记时，不保存新备注；规则要求依据来自已有聊天、资料或记忆，不得补写共同经历。
- 自定义 APP 的稳定 `appId` 会纳入平台身份提示词，身份库提供通用读写和解析函数。
- 校园论坛的身份解析设有匿名保护：不生成、不猜测、不改写学号/固定匿名 ID，也不回退为角色真名。

## 安装步骤

### 第 0 步：先备份 q8

在 GitHub 打开 `liquorcloud0818-create/qqqqqqq8`，确认当前分支是 `main`。建议先下载当前仓库 ZIP 保存一份，作为回滚备份。

### 第 1 步：把补丁 ZIP 上传到仓库根目录

把 `q8-platform-identity-upgrade.zip` 上传到仓库最外层，也就是和 `package.json`、`README` 同一层。**不要先解压，也不要把 ZIP 里的文件逐个手动覆盖。**

### 第 2 步：添加工作流文件

在 GitHub 仓库中创建文件：

`.github/workflows/apply-platform-identity-upgrade.yml`

把本补丁包中 `workflows/apply-platform-identity-upgrade.yml` 的完整内容粘进去并提交到 `main`。

### 第 3 步：允许 Actions 创建 PR

进入仓库 `Settings → Actions → General`，找到 Workflow permissions。允许工作流拥有读写仓库权限；若页面有 “Allow GitHub Actions to create and approve pull requests”，也要打开。保存设置。

### 第 4 步：运行工作流

进入仓库 `Actions`，选择 `Apply q8 Platform Identity Upgrade`，点击 `Run workflow`，分支选择 `main`，再点绿色的 `Run workflow`。

工作流会自动解压补丁、按文件内容定位点修改代码、执行 `npm ci` 和 `npm run typecheck`。只有检查通过后，才会推送功能分支并创建 Pull Request。

### 第 5 步：检查 PR，再决定是否合并

打开 Actions 创建的 PR，先看 `Files changed` 和检查结果。确认没有意外文件改动、类型检查成功后，再合并到 `main`。不要直接跳过 PR 检查。

如果 Actions 失败，先不要合并。打开失败的工作流日志，把红色报错部分发来即可；补丁脚本设置了定位校验，找不到预期代码时会停止，不会盲目替换附近内容。

## 当前集成边界，务必先看

1. **校园论坛的真实 appId 与资料显示组件尚未从 q8 源码中确认。** 本补丁不会猜学号，也不会自动改论坛匿名身份。要完成论坛页面接入，需要该 APP 的真实稳定 ID、显示名称，以及它目前保存学号/匿名 ID 的字段，并在该页面调用 `resolvePlatformIdentity(character, appId, { platformLabel, fixedAnonymousId })`。固定 ID 必须取自原有论坛数据。
2. **自定义 APP 的身份库与提示词已经接入，但每个自定义 APP 的页面是独立代码。** 它需要在自己的资料显示位置调用 `resolvePlatformIdentity()`，才能把独立网名和头像显示出来。仅安装了自定义 APP 并不代表它的 UI 已自动改造。
3. **头像库已经有独立素材与 API，但暂时没有新增可视化管理页面。** 当前可以使用内置头像；额外外链素材须是 HTTPS 图片直链，可由项目后续设置页接入 `addSocialAvatarAsset()`。
4. **并非所有 q8 APP 都已有角色公开账号资料模型。** 本次明确接入的是上述现有资料模型，短信/Theqoo 等没有确认到角色账号资料模型的模块不会被宣称为端到端完成。
5. **备注依据是生成约束与保存门槛，不是数据库级事实审计。** 模型必须引用已注入的聊天/记忆信息，并给出依据标记；这能阻止无依据标记的备注写入，但模型给出的依据仍需结合真实记忆检查，不能当作绝对防幻觉证明。

## 回滚

如果合并后发现问题，在 GitHub 的 `main` 分支对该 PR 执行 Revert，或恢复第 0 步下载的备份。不要用旧 ZIP 覆盖整个仓库。
